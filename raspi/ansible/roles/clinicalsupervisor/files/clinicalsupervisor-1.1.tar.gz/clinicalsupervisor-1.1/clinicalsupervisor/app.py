"""
ucdv_vent_infrastructure "Platform for collecting, aggregating, and storing ventilator data"
Copyright (C) 2017 Gregory Rehm

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
"""
Factory entry point for the Flask application.

Allows development and deployment to configurate the Flask
instance differently.
"""
from flask import Flask

from clinicalsupervisor.configure import configure_app


def create_app(debug=False, testing=False):
    """
    Create and configure the application.
    """
    app = Flask(__name__.split('.')[0])
    configure_app(app, debug=debug, testing=testing)
    return app
