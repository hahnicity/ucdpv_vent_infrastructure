=======
clinicalsupervisor app
=======

A simple GUI for handling everything for the B2C project
